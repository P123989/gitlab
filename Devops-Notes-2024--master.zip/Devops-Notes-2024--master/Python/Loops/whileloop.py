count = 0
while count < 5:
    print(count)
    count += 1