# for i in range(1,10):
#     print(i)
    
# for i in range(1,10):
#     print(i)
#     print("manoj")
    
# friends = ["manoj", "ravi", "seshu"]
# for x in friends:
#     print(x)

# # Break controls
# numbers = [1, 2, 3, 4, 5]
# for number in numbers:
#     if number == 3:
#         break
#     print(number)
    
# Continuous statement
numbers = [1, 2, 3, 4, 5]
for number in numbers:
    if number == 3:
        continue
    print(number)