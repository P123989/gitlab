import os

folder = input("please provide the list of folders with between spaces: ").split
print(folder)


https://youtu.be/cpgOgRxZ0r8?si=70xQZ_ljbq456qpW

