name = {"manoj", "ravi", "raja"}
print(name)
print(type(name))
name.add("sai")               # Adding
print(name)
name.update(["ravi", "seshu"])   # To add the multiple elements
print(name)
delete = name.remove("manoj")
print(name)
makrs = {"12", "34", "56"}
print(makrs.pop())
print(makrs)
del name
print(name)
  