a = 100
b = 100
print(type(a==b))
print(a==b)

a = 100
b = 0
print(type(a==b))
print(bool(a))
print(bool(b))
