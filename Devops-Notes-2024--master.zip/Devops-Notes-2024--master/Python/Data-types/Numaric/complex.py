# Complex
marks = 67 + 5j
total = 100 + 7J
print(marks + total)
print(type(marks))
print(marks.real)   # It give the first number in marks
print(marks.imag)    # It give the second number in marks
print(marks.conjugate())