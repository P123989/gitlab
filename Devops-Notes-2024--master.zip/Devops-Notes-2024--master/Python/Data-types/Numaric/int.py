# integer(int)
marks = 100
print(marks)    # It print the data
print(type(marks))   # It show the data type

print("ravi")    # It will print the name

raja = 18
ravi = -14
print(ravi + raja)    # It add the values
print(type(ravi))

# Integer variables
num1 = 10
num2 = 5

# Addition
result0 = num1 + num2
print("Addition:", result0)

# Integer Division
result1 = num1 // num2
print("Integer Division:", result1)

# Modulus (Remainder)
result2 = num1 % num2
print("Modulus (Remainder):", result2)

# Absolute Value                
result3 = abs(-7)                          # It will print the positive number
print("Absolute Value:", result3)      

