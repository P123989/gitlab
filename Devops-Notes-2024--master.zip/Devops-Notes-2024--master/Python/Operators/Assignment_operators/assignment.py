a = 5
a += 3
print(a)
print(type(a))