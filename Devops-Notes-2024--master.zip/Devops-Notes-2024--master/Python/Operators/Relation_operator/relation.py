a = 15
b = 50
result = a == b
print(result)

a = 15
b = 50
result = a != b
print(result)

a = 15
b = 50
result = a > b
print(result)

a = 15
b = 50
result = a < b
print(result)

a = 15
b = 50
result = a >= b
print(result)

a = 15
b = 50
result = a <= b
print(result)