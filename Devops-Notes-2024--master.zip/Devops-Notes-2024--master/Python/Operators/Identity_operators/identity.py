a = 12
b = 45
result = a is b
print(result)

a = 12
b = 45
result = a is not b
print(result)