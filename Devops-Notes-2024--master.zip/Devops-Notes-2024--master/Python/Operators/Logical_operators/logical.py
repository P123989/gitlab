a = True
b = False
result = a and b
print(result)


a = True
b = False
result = a or b
print(result)
