# a = 10
# b = 25
# result = a + b
# print(result)

a = 56
b = 67
result = b - a
print(result)
print(type(result))