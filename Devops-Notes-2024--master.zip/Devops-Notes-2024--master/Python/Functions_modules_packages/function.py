a = 10
b = 25
def addition():
    print(a + b)
def sub():
    print(a - b)
def multiplication():
    print(a * b)
def division():
    print(a / b)
    
addition()
sub()
multiplication()
division()

# Another way
def addition(num1, num2):
    add = (num1 + num2)
    print(add)
def sub(num1, num2):
    sub = (num1 - num2)
    print(sub)
def multification(num1, num2):
    multification = (num1 * num2)
    print(multification)
def division(num1, num2):
    division = (num1 / num2)
    print(division)
    
addition(5, 15)
sub(25, 10)
multification(5, 5)
division(25, 5)